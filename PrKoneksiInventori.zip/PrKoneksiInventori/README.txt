## Praktikum 10 - Ubah, Hapus, dan Cari
- SQL tabel barang dipindah ke dao/BarangDAO; kategori ke dao/KategoriDAO.
- Hak database: sql/P10_hak_ubah_hapus.sql (UPDATE, DELETE hanya tabel barang).
- Admin: tambah, ubah, hapus. Petugas: cari dan lihat.
- Bukti: bukti/pertemuan-10, laporan: laporan/Laporan_P10_NIM_Nama.pdf